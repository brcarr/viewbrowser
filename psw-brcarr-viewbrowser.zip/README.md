psw-brcarr-viewbrowser
=====================

Package provides user with ability to browse (and perform basic filtering of) any type of view.
