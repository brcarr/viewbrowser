var define;
define([
    './spec/viewBrowserModuleSpec'
]);