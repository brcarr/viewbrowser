var define;
define(['./js/viewBrowserModule'], function (ViewBrowserModule) {
    'use strict';
    
    var exports = {
        ViewBrowserModule: ViewBrowserModule
    };
    return exports;
});